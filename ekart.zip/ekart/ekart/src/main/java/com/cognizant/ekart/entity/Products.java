package com.cognizant.ekart.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.time.LocalDate;
import com.cognizant.helper.Category;
import com.cognizant.helper.DeliveryType;

@Entity
@Table(name="Products")
/*
 * Business Entity represents database table Products
 */
@NamedQueries(
		{
		@NamedQuery(name="findAllProducts",query="from Products p")
		)
public class Products {
	@Id
	@Column(name="product_title")
	private String productTitle;
	
	@Column(name="product_price")
	private double productPrice;
	
	@Column(name="productStock_Available")
	private String productStockAvailable;
	
	@Column(name="product_Expiry")
	private LocalDate productExpiry;

	@Column(name="product_Category)
	private Category productCategory;
	
	@Column(name="productFree_Delivery")
	private DeliveryType freeDelivery;
	
	public void setProductTitle(String productTitle) {
		this.productTitle= productTitle;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice= productPrice;
	}

	public double getProductPrice() {
		return productPrice;
	}
	
	public String getProductStockAvailable() {
		return productStockAvailable;
	}

	public void setProductStockAvailable(String productStockAvailable) {
		this.productStockAvailable = productStockAvailable;
	}

	public LocalDate getProductExpiry() {
		return productExpiry;
	}

	public void setProductExpiry(LocalDate productExpiry) {
		this.productExpiry= productExpiry;
	}

     public Category getProductCategory(){

          return productCategory;
    }
	public void setProductCategory(Category productCategory) {
		this.productCategory= productCategory;
	}

	
	public DeliveryType getFreeDelivery() {
		return freeDelivery;
	}

	public void setFreeDelivery(DeliveryType freeDelivery) {
		this.freeDelivery = freeDelivery;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((productCategory == null) ? 0 : productCategory.hashCode());
		result = prime * result + ((productExpiry == null) ? 0 : productExpiry.hashCode());
		long temp;
		temp = Double.doubleToLongBits(productPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((productStockAvailable == null) ? 0 : productStockAvailable.hashCode());
		result = prime * result + ((productTitle == null) ? 0 : productTitle.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Products other = (Products) obj;
		if (productCategory != other.productCategory)
			return false;
		if (productExpiry == null) {
			if (other.productExpiry != null)
				return false;
		} else if (!productExpiry.equals(other.productExpiry))
			return false;
		if (Double.doubleToLongBits(productPrice) != Double.doubleToLongBits(other.productPrice))
			return false;
		if (productStockAvailable == null) {
			if (other.productStockAvailable != null)
				return false;
		} else if (!productStockAvailable.equals(other.productStockAvailable))
			return false;
		if (productTitle == null) {
			if (other.productTitle != null)
				return false;
		} else if (!productTitle.equals(other.productTitle))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Products [productTitle=" + productTitle + ", productPrice=" + productPrice + ", productStockAvailable="
				+ productStockAvailable + ", productExpiry=" + productExpiry + ", productCategory=" + productCategory
				+ "]";
	}

	
}
