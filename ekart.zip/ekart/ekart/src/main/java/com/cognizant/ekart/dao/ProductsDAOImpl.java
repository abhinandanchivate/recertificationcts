package com.cognizant.ekart.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.ekart.entity.Products;
import com.cognizant.ekart.helper.Category;
@Repository
public class ProductsDAOImpl implements ProductsDAO {
	
	@PersistenceContext
	private EntityManager manager;

	public List<Products> getAllProducts() {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("findAllProducts");
		List<Products> products=query.getResultList();
		return products;
	}

	@Transactional
	public boolean updateProduct(Products products) {
		// TODO Auto-generated method stub
		manager.merge(products);
      	return true;
	}

}
