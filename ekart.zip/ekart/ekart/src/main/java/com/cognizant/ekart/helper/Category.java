package com.cognizant.ekart.helper;

public enum Category {
/*
 *      Category
 *      1- SMARTPHONES
 *      2- ELECTRONICS
 *      3- SNACKS
 */
	SMARTPHONES(1),ELECTRONICS(2),SNACKS(3);
	
	private int categoryId;
	private Category (int categoryId){
		this.categoryId=categoryId;
	}

	public int getCategoryId(){
		return categoryId;
	}
	
}
