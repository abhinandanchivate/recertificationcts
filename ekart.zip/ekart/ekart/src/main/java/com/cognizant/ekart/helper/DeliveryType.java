package com.cognizant.ekart.helper;

public enum DeliveryType {

	YES(1),NO(0);
	private int value;
	private DeliveryType(int value){
		this.value=value;
	}
	
	public int getStatus(){
		return value;
	}
}
