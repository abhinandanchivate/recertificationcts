package com.cognizant.ekart.service;

import java.util.List;

import com.cognizant.ekart.entity.Products;

public interface ProductsService {
	List<Products> retrieveProductsService();
	boolean updateProductService(Products products);

}
