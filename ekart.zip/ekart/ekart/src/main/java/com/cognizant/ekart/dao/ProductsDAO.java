package com.cognizant.ekart.dao;

import java.util.List;

import com.cognizant.ekart.entity.Products;

public interface ProductsDAO {
	
	List<Products> getAllProducts();
	boolean updateProduct(Products products);
}
