package com.cognizant.ekart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.ekart.entity.Products;
import com.cognizant.ekart.service.ProductService;

@RestController
@RequestMapping("/products")
@EnableAspectJAutoProxy
public class ProductsController {
	@Autowired
	private ProductService productService;
	@GetMapping("/allproducts")
	@PreAuthorize (value="hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<List<Products>> retrieveAllProducts(){
		List<Products> productList=productService.retrieveProductsService();
		ResponseEntity<List<Products>> response=new ResponseEntity<List<Products>>(productsList,HttpStatus.OK);
		return response;
	}
	@PutMapping("updateproduct")
	@PreAuthorize (value="hasRole('USER') or hasRole('ADMIN')")
	public ResponseEntity<Void> updateProduct(@RequestBody Products products)
	{
		boolean updateProduct=productService.updateProductService(products);
		ResponseEntity<Void> response=null;
		if(updateProduct==true)
			response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);	
		else
			response=new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
		return response;
	}
}