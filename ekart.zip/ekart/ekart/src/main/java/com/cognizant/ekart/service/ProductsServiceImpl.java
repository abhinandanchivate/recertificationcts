package com.cognizant.ekart.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ekart.dao.ProductsDAO;
import com.cognizant.ekart.entity.Products;
import com.cognizant.ekart.exception.ProductsException;
import com.cognizant.ekart.helper.Category;

@Service
public class ProductsServiceImpl implements ProductsService {
	@Autowired
	private ProductsDAO productsDAO;

	public List<Products> retrieveProductsService() {
		// TODO Auto-generated method stub
		List<Products> products= productsDAO.getAllProducts();
		if(products.isEmpty()){
			throw new ProductsException("No Products records found");
		}else{	
			return products;
		}
	}
	
	public boolean updateProductService(Products products)   {
		// TODO Auto-generated method stub
		boolean checkUpdation=productsDAO.updateProduct(products);
		if(checkUpdation==false)
			throw new ProductsException("Product Updation failed.....");
		return checkUpdation;
	}
	

}
